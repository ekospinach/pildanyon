<div class="welcome">
   <h2>Selamat Datang di PILDANYON</h2>
   <p style="font-size:18px;">Anda login sebagai <strong><?php echo $_SESSION['user']; ?></strong> dengan hak akses admin</p>
</div>
