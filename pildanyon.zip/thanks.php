<?php
defined('BASEPATH') or die("No Access Allowed");
?>
<div class="text-center" style="padding-top:20px;padding-bottom:40px;">
   <div style="padding-bottom:10px">
      <img src="./assets/img/osis.png" class="img-thanks" alt="Slideshow 1" >
   </div>
   <h2>Terima kasih atas partisipasi anda</h2>
   <p>Suara yang anda berikan menentukan masa depan sekolah</p>
   <a href="./" class="button alert large">Back to Home</a>
</div>
